package com.eligible.flag.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;




@Configuration
@PropertySource("classpath:common.properties")
@ConfigurationProperties(prefix = "commprop")
public class CommonProperties {

	private String apikey;
	private String url;
	private String acceptType;
	private String contentType;
	public String getApikey() {
		return apikey;
	}
	public void setApikey(String apikey) {
		this.apikey = apikey;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getAcceptType() {
		return acceptType;
	}
	public void setAcceptType(String acceptType) {
		this.acceptType = acceptType;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	@Override
	public String toString() {
		return "CommonProperties [apikey=" + apikey + ", url=" + url + ", acceptType=" + acceptType + ", contentType="
				+ contentType + "]";
	}

	
	
	
	
	
	
}
