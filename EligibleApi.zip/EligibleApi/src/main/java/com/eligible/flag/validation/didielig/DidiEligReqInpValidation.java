package com.eligible.flag.validation.didielig;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.eligible.flag.bean.CommonResponse;
import com.eligible.flag.bean.DidiRequestBean;

@Component
public class DidiEligReqInpValidation {

	@Autowired
	private CommonResponse commonResponse;

	Map<String, String> invalidInputFileds = new HashMap<>();

	public Map<String, String> serverSideValidation(DidiRequestBean requestBean) {
		invalidInputFileds.clear();
		this.validateVinNo(requestBean.getVin(), 17, 17);
		this.validateDealerCode(requestBean.getDealerCode(), 5, 5);
		this.validateSource(requestBean.getSource(), 20, 20);
		this.validateLop(requestBean.getLop(), 8, 8);
		this.isValidDate(requestBean.getInServiceDate());

		return invalidInputFileds;
	}

	public void validateVinNo(String vinNo, int maxLength, int minLength) {

		if (vinNo != null && !vinNo.isEmpty()) {
			int vinNoLength = vinNo.length();
			if (vinNoLength >= minLength && vinNoLength <= maxLength) {
				String regex = "^[A-Za-z0-9]*[0-9]{6}$";

				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(vinNo);

				if (!matcher.matches()) {
					invalidInputFileds.put("vin", "enter valid field");
				}
				commonResponse.setErrorCode(null);
			} else {
				commonResponse.setErrorCode("ERR_001");
				invalidInputFileds.put("vin", "enterd filed length is invalid");
			}
		} else {
			invalidInputFileds.put("vin", "field is mandatory");
		}
	}

	public void validateDealerCode(String dealerCode, int maxLength, int minLength) {

		if (dealerCode != null && !dealerCode.isEmpty()) {
			int dealCodeLength = dealerCode.length();
			if (dealCodeLength >= minLength && dealCodeLength <= maxLength) {
				try {
					Integer.parseInt(dealerCode);
				} catch (NumberFormatException e) {
					invalidInputFileds.put("dealerCode", "enterd filed is invalid");
				}
			} else {
				invalidInputFileds.put("dealerCode", "enterd filed length is invalid");
			}
		}
	}

	public void validateSource(String source, int maxLength, int minLength) {
		if (source != null && !source.isEmpty()) {
			int sourceLength = source.length();
			if ((sourceLength >= minLength && sourceLength <= maxLength)) {
				if (!(source.equals("SLB") || source.equals("VIP_PRIVATE_API_URL"))) {
					invalidInputFileds.put("source", "enterd filed must be SLB or VIP_PRIVATE_API_URL");
				}
			} else {
				invalidInputFileds.put("source", "enterd filed length is invalid");
			}
		} else {
			invalidInputFileds.put("source", "field is mandatory");
		}

	}

	/*
	 * public void validateLop(String lop, int maxLength, int minLength) {
	 * 
	 * if (lop != null && !lop.isEmpty()) { int lopLength = lop.length(); if
	 * (lopLength >= minLength && lopLength <= maxLength) { try {
	 * Integer.parseInt(lop); } catch (NumberFormatException e) {
	 * invalidInputFileds.put("lop", "enterd filed is invalid"); } } else {
	 * invalidInputFileds.put("lop", "enterd filed length is invalid"); } } }
	 */

	public void validateLop(String lop, int maxLength, int minLength) {
		if (lop != null && !lop.isEmpty()) {
			int lopLength = lop.length();
			if (lopLength >= minLength && lopLength <= maxLength) {
				try {
					Integer.parseInt(lop);
				} catch (NumberFormatException e) {
					invalidInputFileds.put("lop", "Entered field is invalid");
				}
			} else {
				invalidInputFileds.put("lop", "Entered field length is invalid");
			}
		}
		// If lop is not provided, no action needed, as it's not mandatory.
	}

	public void isValidDate(String dateStr) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);

		if (dateStr == null || dateStr.isEmpty()) {
			invalidInputFileds.put("inServiceDate", "In-Service Date is mandatory");
		} else {
			try {
				dateFormat.parse(dateStr);
			} catch (ParseException e) {
				invalidInputFileds.put("inServiceDate", "Entered field is invalid");
			}
		}
	}
	
	public Map<String, String> getFlagOnLop(String lop){
		int lopLength = lop.length();
		 Map<String, String> responceOnLop = null;
		if (lop.startsWith("18")) {
			 responceOnLop = new HashMap<>();
			responceOnLop.put("eligFlag", "N");
			responceOnLop.put("massage", "The LOP provided is a TSB or RSU lop");
		} else if (lopLength >= 7 && lop.charAt(6) == '9') {
			 responceOnLop = new HashMap<>();
			responceOnLop.put("eligFlag", "N");
			responceOnLop.put("massage", "The LOP provided is a Flash lop");
		}
		return responceOnLop;
	}

}
