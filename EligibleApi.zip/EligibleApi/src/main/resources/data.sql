INSERT INTO VEHICLE_DETAILS_TABLE (MARKET,BRAND, MODEL_YEAR ,BODY_MODEL,ENG_SC,TRANS_SC, DEALER,ZONE1, MIS, ELIG_FLAG,STATUS ,MESSAGE

                                   ,EFFECTIVE_START_DATE ,EFFECTIVE_END_DATE, LOP1_2, LOP3_4, LOP5_6, LOP7_8)

VALUES('M','DODGE',    '2022','MPJP74','EZL','DFT','60000','30','3','Y','A','CustomMsg1', '2023-01-10','2023-02-10','18','19','*','21'),

      ('C','ALFAROMEO','2023','MP09ZK','ESD','DFR','99970','40','4','N','A','CustomMsg2', '2023-1-10','2023-02-10','18','23','*','*'),

      ('U','FIAT',     '1998','GJJL74','ERG','DFV','12345','36','5','Y','A','CustomMsg3', '2023-01-10','2023-02-10','*','19','*','*'),

      ('M','MASERATI',  '1995','MPJP77','ETL','DF3','59999','50','7','Y','A','CustomMsg4', '2023-01-10','2023-02-10','*','*','*','*'),

      ('C','JEEP' ,   '1993',  'ZJJL74','ESD','DF2','78900','60','7','N','A','CustomMsg5', '2023-01-10','2023-02-10','18','35','36','37'),

      ('U','CHRYSLER', '2022','MPJP74','ERB','DG7','60083','10','8','N','A','CustomMsg6', '2023-01-10','2023-02-10','38','19','40','41'),

      ('I','RAM',      '2023','MPJP76','EZH','DF2','60083','35','7','Y','A','CustomMsg7', '2023-01-10','2023-02-10','42','43','44','45'),

      ('I','RAM1',     '2023','MPJP74','EFC','DG7','22222','40','8','Y','A','CustomMsg8', '2023-01-10','2023-02-10','46','47','48','49'),

      ('C','MASERATI1','2023','MP0976','ECX','DFX','61661','51','7','N','A','CustomMsg9', '2023-01-10','2023-02-10','50','51','52','53'),

      ('M','JEEP1',    '2022','MP0474','EC1','DEC','61661','59','8','Y','A','CustomMsg10','2023-01-10','2023-02-10','54','55','56','57'),

      ('U','DODGE1',   '2023','MP0K74','EC2','DEM','99970','36','8','Y','A','CustomMsg11','2023-01-10','2023-02-10','58','59','60','61'),

      ('Z','MASERATI', '2023','MPJP77','ESD','DF2','78900','40','7','Y','A','CustomMsg12', '2023-01-10','2023-02-10','18','35','36','37'),

      ('K','CHRYSLER', '2022','MPJP74','ERB','DG7','60083','40','8','N','A','CustomMsg13', '2023-01-10','2023-02-10','38','19','40','41'),

      ('L','RAM',      '2023','MPJP76','EZH','DF2','60083','40','7','Y','A','CustomMsg14', '2023-01-10','2023-02-10','42','43','44','45'),

      ('O','RAM1',     '2023','MPJP74','EFC','DG7','22222','40','8','Y','A','CustomMsg15', '2023-01-10','2023-02-10','46','47','48','49'),

      ('P','MASERATI1','2023','MP0976','ECX','DFX','61661','40','7','N','A','CustomMsg16', '2023-01-10','2023-02-10','50','51','52','53'),

      ('Q','JEEP',    '2022','MP0474','EC1','DEC','61661','40','8','Y','A','CustomMsg17','2023-01-10','2023-02-10','54','55','56','57'),

      ('R','DODGE1',   '2023','MP0K74','EC2','DEM','99970','40','8','Y','A','CustomMsg18','2023-01-10','2023-02-10','58','59','60','61');

     
INSERT INTO VEHICLE_DETAILS(               VIN, DEALER_CODE,     LOP, RESPONSE_CODE,          MASSAGE, DIDI_Eligibility_Flag,   DIDI_Message)
VALUES					   ('3C4NJDCB4KT616765',      60085, 18190697,            0, 'custome massage',                  'Y', 'Eligilible'),
     					   ('3C4NJDCB4KT625467',     55500,  18190698,            1, 'custome massage',                  'N', 'Not Eligilible'),
                           ('3C4NJDCB4KT987855',     40056,  18190697,            0, 'custome massage',                  'Y', 'Eligilible'),
                           ('3C4NJDCB4KT234532',     99970,  18190697,            1, 'custome massage',                  'N', 'Not Eligilible'),
                           ('3C4NJDCB4KT556714',     69691,  19287658,            0, 'custome massage',                  'Y', 'Eligilible');
      
      


