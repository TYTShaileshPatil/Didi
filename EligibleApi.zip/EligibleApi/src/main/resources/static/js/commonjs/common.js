
// Ajax-Custom-Functions

//url: is mandatory & dataObj: is optional
function ajaxGetMethod(url, dataObj, successCallback) {

	$.ajax({
		url: url,
		method: 'GET',
		data: dataObj,

		success: function(data) {
			successCallback(data);
		},
		error: function() {
			// Handle errors here
			alert("Error is Occours while URL calling")
		}
	})
}


function mapDataToFieldIds(id, respectiveData) {
	return $("#" + id).text(respectiveData);
}

function getValueFromId(id) {
	return $("#" + id).val();
}