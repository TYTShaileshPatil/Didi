function indexAlert() {
	alert("index alert");
	ajaxGetMethod("http://localhost:8080/loadData", null, function(responseData) {
		
		document.getElementById("name").value=responseData.name;
	});
	
}

function loadTableData() {
            $.ajax({
                url: 'http://localhost:8080/loadTableData', // Replace with the URL of your servlet or data source
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                	
                    // Loop through the data and populate the table rows
                    var tableBody = $('#data-table tbody');
                    $.each(data, function(index, row) {
                    	
                    	console.log(row);
                        var newRow = '<tr>' +
                        '<td>' + row.MARKET + '</td>' +
                        '<td>' + row.BRAND + '</td>' +
                        '<td>' + row.MODEL_YEAR + '</td>' +
                        '<td>' + row.BODY_MODEL + '</td>' +
                        '<td>' + row.ENG_SC + '</td>' +
                        '<td>' + row.TRANS_SC+ '</td>' +
                        '<td>' + row.DEALER + '</td>' +
                        '<td>' + row.ZONE1 + '</td>' +
                        '<td>' + row.MIS + '</td>' +
                        '<td>' + row.ELIG_FLAG + '</td>' +
                        '<td>' + row.STATUS + '</td>' +
                        '<td>' + row.MESSAGE + '</td>' +
                        '<td>' + row.EFFECTIVE_START_DATE + '</td>' +
                        '<td>' + row.EFFECTIVE_END_DATE + '</td>' +
                        '<td>' + row.LOP1_2 + '</td>' +
                        '<td>' + row.LOP3_4 + '</td>' +
                        '<td>' + row.LOP5_6 + '</td>' +
                        '<td>' + row.LOP7_8 + '</td>' +
                            // Add more columns as needed
                            '</tr>';
                        tableBody.append(newRow);
                    });
                },
                error: function() {
                    alert('Error fetching data.');
                }
            });

}
	
